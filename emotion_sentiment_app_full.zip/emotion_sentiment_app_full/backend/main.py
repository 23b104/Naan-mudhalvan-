from fastapi import FastAPI, Request
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import uvicorn
import torch.nn.functional as F

# Emotion Model
emotion_tokenizer = AutoTokenizer.from_pretrained("j-hartmann/emotion-english-distilroberta-base")
emotion_model = AutoModelForSequenceClassification.from_pretrained("j-hartmann/emotion-english-distilroberta-base")

# Dummy sarcasm model (replace with your own logic)
def is_sarcastic(text):
    if "yeah right" in text.lower() or "sure" in text.lower():
        return True, 0.85
    return False, 0.15

class TextInput(BaseModel):
    text: str

app = FastAPI()

@app.post("/predict")
def predict(input: TextInput):
    inputs = emotion_tokenizer(input.text, return_tensors="pt")
    outputs = emotion_model(**inputs)
    probs = F.softmax(outputs.logits, dim=1).detach().numpy()[0]
    labels = emotion_model.config.id2label

    # Only return emotions with score > 0
    result = {labels[i]: float(score) for i, score in enumerate(probs) if score > 0.0}
    return result

@app.post("/detect_sarcasm")
def detect_sarcasm(input: TextInput):
    sarcastic, confidence = is_sarcastic(input.text)
    return {
        "sarcastic": sarcastic,
        "confidence": round(confidence, 2),
        "message": "😏 It's likely sarcastic." if sarcastic else "🙂 Not sarcastic."
    }

if __name__ == "__main__":
    uvicorn.run("main:app", port=8000, reload=True)
